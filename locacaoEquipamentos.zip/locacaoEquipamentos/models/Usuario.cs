﻿namespace locacaoEquipamentos.models
{
    public class Usuario
    {
        public int id;
        public string nome;
        public string email;
        public string senha;
    }
}
